# Status Page

Projeto Vite + React + Tailwind + shadcn-ui.

## Desenvolvimento

- Node 18+
- `npm install`
- `npm run dev`

## Build

- `npm run build`
- `npm run preview`

## Licença

Sem atribuições a ferramentas externas.
